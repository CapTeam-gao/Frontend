import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import "./Login.css";
import Button from "../components/common/Button";
import Logo from "../assets/images/logo.png";

const Login = () => {
    const [studentId, setStudentId] = useState("");
    const [password, setPassword] = useState("");
    const isDisabled = !studentId || !password;
    return (
        <div className="login-container">
            <div className="login-header">
                <img className="logo" src={Logo} alt="로고" />
                <p className="login-title">로그인</p>
                <p className="login-subtitle">
                    서비스를 이용하려면 로그인하세요
                </p>
            </div>
            <div className="login-form">
                <div className="studentId">
                    <label htmlFor="studentId">학번</label>
                    <input
                        type="text"
                        placeholder="학번을 입력해주세요"
                        id="studentId"
                        onChange={(e) => setStudentId(e.target.value)}
                    />
                </div>
                <div className="password">
                    <label htmlFor="password">비밀번호</label>
                    <input
                        type="password"
                        placeholder="비밀번호를 입력해주세요"
                        id="password"
                        onChange={(e) => setPassword(e.target.value)}
                    />
                </div>
                <Button
                    buttonSize="large"
                    buttonColor="primary"
                    disabled={isDisabled}
                >
                    로그인
                </Button>
            </div>
        </div>
    );
};

export default Login;
